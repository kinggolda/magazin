<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Простой сайт</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Добро пожаловать на сайт!</h1>
        <?php
        require_once 'db_config.php';

        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            if ($_SESSION['is_admin']) {
                header("Location: admin_panel.php");
                exit;
            } else {
                header("Location: profile.php");
                exit;
            }
        } else {
            echo "<p><a href='register.php'>Зарегистрироваться</a></p>";
            echo "<p><a href='login.php'>Войти</a></p>";
        }
        ?>
    </div>
</body>
</html>