<?php
session_start();
require_once 'db_config.php';

// Проверка авторизации администратора
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    echo "<p class='error'>Доступ запрещен! Вы не являетесь администратором.</p>";
    echo "<p><a href='index.php'>Вернуться на главную страницу</a></p>";
    exit;
}

// Получение информации об администраторе (можно упростить)
$user_id = $_SESSION['user_id'];
// ... (получение имени пользователя -  оптимизируйте, если нужно только имя) ...


?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админская панель</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>Админская панель</h1>

    <?php
        // Проверка подключения к базе данных
        if (!$conn) {
            die("Ошибка подключения к базе данных: " . $conn->connect_error);
        }

        // Вывод информации о пользователе (Упрощенный вариант)
        echo "<p>Привет, " . $_SESSION['username'] . "!</p>"; // предполагается, что username есть в $_SESSION

        // Вывод списка заказов яблок
        echo "<h2>Заказы яблок</h2>";
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Пользователь</th>";
        echo "<th>Сорт яблок</th>";
        echo "<th>Количество</th>";
        echo "<th>Дата заказа</th>";
        echo "<th>Статус</th>";
        echo "<th>Действие</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        $sql = "SELECT ao.id, u.fullname, ao.apple_variety, ao.quantity, ao.order_date, ao.status 
                FROM apple_orders ao 
                JOIN users u ON ao.user_id = u.id 
                ORDER BY ao.id DESC";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["fullname"] . "</td>";
                echo "<td>" . $row["apple_variety"] . "</td>";
                echo "<td>" . $row["quantity"] . "</td>";
                echo "<td>" . $row["order_date"] . "</td>";
                echo "<td>" . $row["status"] . "</td>";
                echo "<td><a href='update_request.php?id=" . $row["id"] . "'>Изменить статус</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>Нет заказов.</td></tr>";
        }
        echo "</tbody>";
        echo "</table>";
    ?>

    <p><a href='logout.php'>Выйти</a></p>
</body>
</html>