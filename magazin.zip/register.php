<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Регистрация</h1>
        <?php
        require_once 'db_config.php';

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $fullname = $_POST['fullname'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];

            // Проверка на пустые поля
            if (empty($username) || empty($password) || empty($fullname) || empty($phone) || empty($email)) {
                echo "<p class='error'>Заполните все поля!</p>";
            } else {
                // Проверка, есть ли такой пользователь в базе данных
                $sql = "SELECT * FROM users WHERE username = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    echo "<p class='error'>Пользователь с таким именем уже существует!</p>";
                } else {
                    // Создание пользователя в базе данных
                    $sql = "INSERT INTO users (username, password, fullname, phone, email) VALUES (?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sssss", $username, $password, $fullname, $phone, $email);

                    if ($stmt->execute()) {
                        echo "<p class='success'>Регистрация прошла успешно!</p>";
                        echo "<p>Перейдите на страницу <a href='login.php'>входа</a>.</p>";
                    } else {
                        echo "<p class='error'>Ошибка при регистрации!</p>";
                    }
                }
            }
        }
        ?>
        <form method="POST">
            <label for="username">Имя пользователя:</label><br>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Пароль:</label><br>
            <input type="password" id="password" name="password" required><br>
            <label for="fullname">ФИО:</label><br>
            <input type="text" id="fullname" name="fullname" required><br>
            <label for="phone">Телефон:</label><br>
            <input type="text" id="phone" name="phone" required><br>
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>
            <input type="submit" value="Зарегистрироваться">
        </form>
    </div>
</body>
</html>
