<?php
session_start();
require_once 'db_config.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Проверка на пустые поля
    if (empty($username) || empty($password)) {
        echo "<p class='error'>Заполните все поля!</p>";
    } else {
        // Проверка в базе данных
        $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['is_admin'] = $row['is_admin']; // Проверяем, является ли пользователь админом

            // Перенаправление на соответствующую страницу
            if ($_SESSION['is_admin']) {
                header("Location: admin_panel.php");
                exit; // Выход после перенаправления
            } else {
                header("Location: profile.php");
                exit; // Выход после перенаправления
            }
        } else {
            echo "<p class='error'>Неверный логин или пароль!</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Вход</h1>
        <form method="POST">
            <label for="username">Имя пользователя:</label><br>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Пароль:</label><br>
            <input type="password" id="password" name="password" required><br><br>
            <input type="submit" value="Войти">
        </form>
    </div>
</body>
</html> 
