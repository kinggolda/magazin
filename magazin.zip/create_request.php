<?php
session_start();
require_once 'db_config.php';

// Проверка соединения с БД (остается без изменений)
if (!$conn) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Проверка авторизации (остается без изменений)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Массив сортов яблок (теперь в коде)
$apple_varieties = [
    "Антоновка",
    "Гала",
    "Гренни Смит",
    "Голден Делишес",
    "Фуджи",
    "Ред Делишес",
    "Семеренко",
    "Айдаред"
];

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание заказа яблок</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Создание заказа яблок</h1>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user_id = $_SESSION['user_id'];
            $apple_variety = $_POST['apple_variety'];
            $quantity = $_POST['quantity'];

            // Валидация (остается без изменений)
            if (empty($apple_variety)) {
                echo "<p class='error'>Выберите сорт яблок.</p>";
            } elseif (!is_numeric($quantity) || $quantity <= 0) {
                echo "<p class='error'>Некорректное количество.</p>";
            } else {
                // Запрос к базе данных (остается без изменений)
                $sql = "INSERT INTO apple_orders (user_id, apple_variety, quantity, status) VALUES (?, ?, ?, 'В обработке')";
                $stmt = $conn->prepare($sql);
                if ($stmt === false) {
                    echo "<p class='error'>Ошибка подготовки запроса: " . $conn->error . "</p>";
                } else {
                    $stmt->bind_param("isi", $user_id, $apple_variety, $quantity);
                    if ($stmt->execute() === false) {
                        echo "<p class='error'>Ошибка выполнения запроса: " . $stmt->error . "</p>";
                    } else {
                        echo "<p class='success'>Заказ создан успешно!</p>";
                    }
                    $stmt->close();
                }
            }
        }
        ?>
        <form method="POST">
            <label for="apple_variety">Сорт яблок:</label><br>
            <select id="apple_variety" name="apple_variety" required>
                <?php foreach ($apple_varieties as $variety): ?>
                    <option value="<?php echo htmlspecialchars($variety); ?>"><?php echo htmlspecialchars($variety); ?></option>
                <?php endforeach; ?>
            </select><br><br>

            <label for="quantity">Количество:</label><br>
            <label for="quantity">:Цена: 500р 1кг</label><br>
            <input type="number" id="quantity" name="quantity" min="1" value="1" required>
            <input type="range" id="quantity-range" name="quantity" min="1" max="100" value="1" oninput="this.previousElementSibling.value = this.value"> <br><br>

            <input type="submit" value="Создать заказ">
        </form>
        <p><a href="profile.php">Вернуться на профиль</a></p>
    </div>
</body>
</html>

