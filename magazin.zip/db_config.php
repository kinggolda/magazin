<?php
// Параметры подключения к базе данных
$servername = "localhost";
$username = "u2870730_default";
$password = "5OohHQMRP946la8U";
$dbname = "u2870730_default";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Установка кодировки
$conn->set_charset("utf8mb4"); // обязательно для UTF-8
?>