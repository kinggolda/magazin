<?php
session_start();
require_once 'db_config.php';

// Проверка авторизации (без изменений)
if (!isset($_SESSION['user_id'])) {
    echo "<p class='error'>Вы должны авторизоваться, чтобы войти в личный кабинет!</p>";
    echo "<p><a href='login.php'>Войти</a></p>";
    exit;
}

// Получение информации о пользователе (без изменений)
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Вывод информации о пользователе (без изменений)
echo "<div class='user-info'>";
echo "<p>Привет, " . $user['fullname'] . "!</p>";
echo "<p>Ваш логин: " . $user['username'] . "</p>";
echo "<p>Ваш телефон: " . $user['phone'] . "</p>";
echo "<p>Ваш email: " . $user['email'] . "</p>";
echo "</div>";

// Вывод списка заказов яблок
echo "<h2>Ваши заказы яблок</h2>";
echo "<table class='requests-table'>";
echo "<thead>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Сорт яблок</th>";
echo "<th>Количество</th>";
echo "<th>Дата заказа</th>";
echo "<th>Статус</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

$sql = "SELECT * FROM apple_orders WHERE user_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['apple_variety'] . "</td>";
        echo "<td>" . $row['quantity'] . "</td>";
        echo "<td>" . $row['order_date'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>Нет заказов.</td></tr>";
}
echo "</tbody>";
echo "</table>";

// Кнопка для создания нового заказа
echo "<p><a href='create_request.php'>Создать новый заказ яблок</a></p>"; // Изменена ссылка
?>
<p><a href='logout.php'>Выйти</a></p>
</div>
</body>
</html>

