<?php
session_start();
require_once 'db_config.php';

// Проверка авторизации администратора
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    echo "<p class='error'>Доступ запрещен! Вы не являетесь администратором.</p>";
    echo "<p><a href='index.php'>Вернуться на главную страницу</a></p>";
    exit;
}

$orderId = isset($_GET['id']) && is_numeric($_GET['id']) ? $_GET['id'] : null;

if (!$orderId) {
    echo "<p class='error'>Не указан ID заказа.</p>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newStatus = $_POST['status'];

    // Обновление статуса заказа в базе данных
    $sql = "UPDATE apple_orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo "<p class='error'>Ошибка подготовки запроса: " . $conn->error . "</p>";
        exit;
    }
    $stmt->bind_param("si", $newStatus, $orderId);

    if ($stmt->execute()) {
        echo "<p class='success'>Статус заказа обновлен!</p>";
        echo "<p><a href='admin_panel.php'>Вернуться на админ-панель</a></p>";
    } else {
        echo "<p class='error'>Ошибка при обновлении статуса: " . $stmt->error . "</p>";
    }
    $stmt->close();
} else {
    // Получение информации о заказе
    $sql = "SELECT status FROM apple_orders WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo "<p class='error'>Ошибка подготовки запроса: " . $conn->error . "</p>";
        exit;
    }
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $currentStatus = $row['status'] ?? 'В обработке'; //Обработка случая, если запись не найдена
    $stmt->close();

    ?>
    <form method="POST">
        <label for="status">Новый статус:</label><br>
        <select id="status" name="status" required>
            <option value="В обработке" <?php if ($currentStatus == "В обработке") echo "selected"; ?>>В обработке</option>
            <option value="Выполнен" <?php if ($currentStatus == "Выполнен") echo "selected"; ?>>Выполнен</option>
            <option value="Отменен" <?php if ($currentStatus == "Отменен") echo "selected"; ?>>Отменен</option>
        </select><br><br>
        <input type="submit" value="Обновить статус">
    </form>
    <?php
}
?>
</body>
</html>

